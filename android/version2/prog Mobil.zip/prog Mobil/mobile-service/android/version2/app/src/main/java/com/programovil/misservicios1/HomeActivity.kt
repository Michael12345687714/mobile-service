package com.programovil.misservicios1

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.graphics.drawable.VectorDrawable
import android.location.Location
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class HomeActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    private lateinit var mMap: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private var currentUserMarker: Marker? = null
    private var isSelected = false

    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1
        private const val USER_ICON_SIZE_DP = 50  // Tamaño para el icono del usuario
        private const val PROVIDER_ICON_SIZE_DP = 40  // Tamaño para los iconos de proveedores
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Inicialización de vistas y listeners
        initViews()
        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    private fun initViews() {
        val waterContainer = findViewById<LinearLayout>(R.id.waterContainer)
        val gasContainer = findViewById<LinearLayout>(R.id.gasContainer)
        val garbageContainer = findViewById<LinearLayout>(R.id.garbageContainer)
        val filterButton = findViewById<ImageView>(R.id.filterButton)
        val requestButton = findViewById<Button>(R.id.requestButton)
        val drawerLayout = findViewById<DrawerLayout>(R.id.drawerLayout)
        val menuButton = findViewById<View>(R.id.menuButton)

        var selectedService: LinearLayout? = null

        fun selectService(container: LinearLayout) {
            selectedService?.isSelected = false
            container.isSelected = true
            selectedService = container

            when (container.id) {
                R.id.waterContainer -> Toast.makeText(this, "Servicio de agua seleccionado", Toast.LENGTH_SHORT).show()
                R.id.gasContainer -> Toast.makeText(this, "Servicio de gas seleccionado", Toast.LENGTH_SHORT).show()
                R.id.garbageContainer -> Toast.makeText(this, "Servicio de basura seleccionado", Toast.LENGTH_SHORT).show()
            }
        }

        waterContainer.setOnClickListener { selectService(waterContainer) }
        gasContainer.setOnClickListener { selectService(gasContainer) }
        garbageContainer.setOnClickListener { selectService(garbageContainer) }

        filterButton.setOnClickListener {
            Toast.makeText(this, "Filtrar servicios", Toast.LENGTH_SHORT).show()
        }

        requestButton.setOnClickListener {
            if (selectedService == null) {
                Toast.makeText(this, "Por favor seleccione un servicio", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Solicitar servicio", Toast.LENGTH_SHORT).show()
            }
        }

        supportFragmentManager.beginTransaction()
            .replace(R.id.drawerFragmentContainer, UserDrawerFragment())
            .commit()

        menuButton.setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        checkLocationPermission()
        listenToOnlineUsers()
    }

    private fun checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        } else {
            enableMyLocation()
        }
    }

    private fun enableMyLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED) {

            mMap.isMyLocationEnabled = true

            val locationRequest = LocationRequest.create().apply {
                interval = 5000
                fastestInterval = 3000
                priority = LocationRequest.PRIORITY_HIGH_ACCURACY
            }

            locationCallback = object : LocationCallback() {
                override fun onLocationResult(locationResult: LocationResult) {
                    val location = locationResult.lastLocation ?: return
                    val latLng = LatLng(location.latitude, location.longitude)

                    if (currentUserMarker == null) {
                        val userIcon = getBitmapDescriptorFromVector(
                            R.drawable.ic_garbage_truck,
                            USER_ICON_SIZE_DP,
                            USER_ICON_SIZE_DP
                        )

                        currentUserMarker = mMap.addMarker(
                            MarkerOptions()
                                .position(latLng)
                                .title("Tu ubicación")
                                .icon(userIcon)
                        )
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15f))
                    } else {
                        currentUserMarker?.position = latLng
                    }

                    val uid = auth.currentUser?.uid
                    val userLocation = hashMapOf(
                        "latitude" to location.latitude,
                        "longitude" to location.longitude,
                        "isOnline" to true
                    )
                    uid?.let { db.collection("locations").document(it).set(userLocation) }
                }
            }

            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, mainLooper)
        }
    }

    private fun listenToOnlineUsers() {
        val currentPosition = currentUserMarker?.position
        val currentTitle = currentUserMarker?.title

        db.collection("locations")
            .whereEqualTo("isOnline", true)
            .addSnapshotListener { snapshots, e ->
                if (e != null) {
                    Toast.makeText(this, "Error al obtener ubicaciones", Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }

                mMap.clear()

                // Agrega de nuevo la ubicación del usuario actual
                currentPosition?.let { position ->
                    val userIcon = getBitmapDescriptorFromVector(
                        R.drawable.ic_gas_truck, // Usa el icono adecuado
                        USER_ICON_SIZE_DP,
                        USER_ICON_SIZE_DP
                    )
                    currentUserMarker = mMap.addMarker(
                        MarkerOptions()
                            .position(position)
                            .title(currentTitle ?: "Tu ubicación")
                            .icon(userIcon)
                    )
                }

                snapshots?.forEach { doc ->
                    val lat = doc.getDouble("latitude") ?: return@forEach
                    val lng = doc.getDouble("longitude") ?: return@forEach
                    val userId = doc.id

                    // Evita mostrar tu propia ubicación como servicio
                    if (userId == auth.currentUser?.uid) return@forEach

                    // Verifica si es un usuario de tipo "Servicio"
                    db.collection("userServices").document(userId).get()
                        .addOnSuccessListener { serviceDoc ->
                            if (serviceDoc.exists()) {
                                val userType = serviceDoc.getString("userType")
                                if (userType == "Servicio") {
                                    val serviceType = serviceDoc.getString("serviceType") ?: "Desconocido"
                                    val username = serviceDoc.getString("username") ?: "Servicio"

                                    val icon = when (serviceType.lowercase()) {
                                        "agua" -> getBitmapDescriptorFromVector(R.drawable.ic_water_truck, PROVIDER_ICON_SIZE_DP, PROVIDER_ICON_SIZE_DP)
                                        "basura" -> getBitmapDescriptorFromVector(R.drawable.ic_garbage_truck, PROVIDER_ICON_SIZE_DP, PROVIDER_ICON_SIZE_DP)
                                        "gas" -> getBitmapDescriptorFromVector(R.drawable.ic_gas_truck, PROVIDER_ICON_SIZE_DP, PROVIDER_ICON_SIZE_DP)
                                        else -> getBitmapDescriptorFromVector(R.drawable.ic_filter, PROVIDER_ICON_SIZE_DP, PROVIDER_ICON_SIZE_DP)
                                    }

                                    mMap.addMarker(
                                        MarkerOptions()
                                            .position(LatLng(lat, lng))
                                            .title("Servicio: $username ($serviceType)")
                                            .icon(icon)
                                    )
                                }
                            }
                        }
                }
            }
    }



    private fun getBitmapDescriptorFromVector(
        vectorResId: Int,
        widthDp: Int,
        heightDp: Int
    ): BitmapDescriptor? {
        return try {
            val vectorDrawable = ContextCompat.getDrawable(this, vectorResId) ?: return null

            // Convertir dp a píxeles
            val widthPx = (widthDp * resources.displayMetrics.density).toInt()
            val heightPx = (heightDp * resources.displayMetrics.density).toInt()

            val bitmap = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            vectorDrawable.setBounds(0, 0, canvas.width, canvas.height)
            vectorDrawable.draw(canvas)

            BitmapDescriptorFactory.fromBitmap(bitmap)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE && grantResults.isNotEmpty()
            && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            enableMyLocation()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        auth.currentUser?.uid?.let { uid ->
            db.collection("locations").document(uid).update("isOnline", false)
        }
        if (::locationCallback.isInitialized) {
            fusedLocationClient.removeLocationUpdates(locationCallback)
        }
    }
}

// Extensión para clonar un MarkerOptions existente
